<template>
  <div id="app">
    <b-container fluid>
      <b-card>
        <b-card-text>
          <!--v-for -->
              <b-row class="my-1" v-for="(subject,i) in moduleList" :key="i">
                <b-col sm="9">
                  <label>{{ subject.title }}: </label>
                </b-col>
                <b-col sm="1">
                  <label>{{ subject.note}}</label>
                </b-col>
                <b-col sm="5">
                  <b-form-input :id="`${subject.mid}`" v-model:value="subject.note" ref="input"
                                @keyup.enter="setNote(subject.sid,subject.mid,subject.note)"></b-form-input>
                </b-col>
                <b-col sm="2">
                  <b-button variant="primary"
                            @click="setNote(subject.sid,subject.mid, subject.note)">Update</b-button>
                </b-col>
              </b-row>
            <h5>Durchschnitt {{ this.avg }}</h5>
        </b-card-text>
      </b-card>
    </b-container>
  </div>
</template>

<script>
export default {
  name: 'app',
  data() {
    return {
      student1: 15,
      student2: 60,
      NotenList: [],
      avg: 0
    }
  },
  beforeMount() {
    this.NotenList = this.$store.getters.getByStudentId(this.student2);
    this.avg = this.getAvg(this.student2);
    console.log(`beforeMount: ${this.avg}`);
  },
  methods: {
    getAvg(sid) {
        let sum = 0, count = 0;
        this.NotenList.forEach(mod => {
          if (mod.sid === sid) {
            if (mod.note !== 'Pnab') {
              sum += Number(mod.note);
              count++;
            }
          }
        });

        <!-- Note Runden-->
        console.log(`${sum} ${count}`);
        return Number((Math.round((sum / count) / .5) * .5).toFixed(2));
    },
    setNote(sid,mid,note){
      console.log(`before if: ${sid} ${mid} ${note}`);
      this.avg = this.getAvg(this.student2);
      if (note){
        console.log(`in if: ${sid} ${mid} ${note}`);
        this.$store.commit('updateNote',this.moduleList);
      }
    },
    infocard(sid){
      return `Module Student id=${sid}`
    }
  }

}
</script>

<style lang="scss" scoped>
b-card {
  border: 1px solid black;
}
</style>

