<template>
  <div>
      <h1>Welcome to my Vue project!</h1>
  </div>
</template>
