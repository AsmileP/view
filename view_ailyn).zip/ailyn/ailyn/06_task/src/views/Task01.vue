<template>

  <div>
    <h1 v-if="false" v-text="text">Loading...</h1>
    <h2 v-else-if="true" v-html="html" />
    <a
        v-else
        :href="link.url"
        :target="link.target"
        :tabindex="link.tabindex"
        v-text="link.title"
    />
  </div>
</template>

<script>
export default {
  data() {
    return {
      // v-text
      text: 'Ausverkauft',
      // v-html
      html: '<b>Keine Artikel im Lager</b>',
      // v-bind
      link: {
        url: 'https://www.jeeg.ch/',
        target: '_blank',
        tabindex: '0',
        title: 'Besuche den Shop!',
      },
    }
  },
}
</script>

<style lang="scss" scoped>
h2 {
  margin: 40px 0 0;
  font-weight: normal;
}
a {
  display: block;
  margin-top: 40px;
}
</style>
